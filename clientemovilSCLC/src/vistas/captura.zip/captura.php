<?php

$nombre = $_POST["nombre"];
// $curp = $_POST["curp"];
// $claveElectoral = $_POST["claveElectoral"];


// echo "nombre: $nombre curp: $curp clave electorial: $claveElectoral "
echo "nombre:$nombre curp: "
?>